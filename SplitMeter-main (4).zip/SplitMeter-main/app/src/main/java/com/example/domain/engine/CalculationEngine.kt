package com.example.domain.engine

import com.example.domain.model.BillingCycle
import com.example.domain.model.Member
import com.example.domain.model.MemberResult
import com.example.domain.model.Reading
import kotlin.math.abs

class CalculationException(message: String) : Exception(message)

object CalculationEngine {

    /**
     * Executes the deterministic 8-step calculation sequence.
     */
    fun calculate(
        billingCycle: BillingCycle,
        members: List<Member>,
        readings: List<Reading>
    ): List<MemberResult> {
        // Step 1: Units per reading = OFF Reading - ON Reading (Calculated and validated per reading)
        val validReadings = readings.map { reading ->
            val calculatedUnits = reading.offReading - reading.onReading
            if (calculatedUnits < 0) {
                throw CalculationException(
                    "Invalid reading found: Sequence ${reading.sequence} has OFF (${reading.offReading}) less than ON (${reading.onReading})."
                )
            }
            reading.copy(units = calculatedUnits)
        }

        // Step 2: Sum all reading units by unique member to compute individual "Recorded Units"
        val recordedUnitsByMember = members.associate { member ->
            val memberReadings = validReadings.filter { it.memberId == member.id }
            val recordedUnits = memberReadings.sumOf { it.units }
            member.id to recordedUnits
        }

        // Step 3: Sum all member recorded units to find Total Recorded Units
        val totalRecordedUnits = recordedUnitsByMember.values.sum()

        // Step 4: Calculate Adjustment Units = Bill Units - Total Recorded Units
        val adjustmentUnits = billingCycle.billUnits - totalRecordedUnits

        // Step 5: Compute Unit Rate = (Bill Amount + Additional Fixed Charge) / Bill Units
        val totalCost = billingCycle.billAmount + billingCycle.additionalFixedCharge
        if (billingCycle.billUnits <= 0) {
            throw CalculationException("Bill Units must be greater than zero.")
        }
        val unitRate = totalCost / billingCycle.billUnits

        // Steps 6, 7 & 8: Compute individual metrics for each active/participating member
        val results = members.map { member ->
            val recordedUnits = recordedUnitsByMember[member.id] ?: 0.0

            // Step 6: Calculate individual Adjustment Share = (Member's Weekly Hours / 168) * Adjustment Units
            val adjustmentShare = (member.weeklyHours / 168.0) * adjustmentUnits

            // Step 7: Compute Effective Units = Recorded Units + Adjustment Share
            val effectiveUnits = recordedUnits + adjustmentShare

            // Step 8: Compute Payable Amount = Effective Units * Unit Rate
            val payableAmount = effectiveUnits * unitRate

            MemberResult(
                billingId = billingCycle.id,
                memberId = member.id,
                recordedUnits = recordedUnits,
                adjustmentUnits = adjustmentShare,
                effectiveUnits = effectiveUnits,
                amount = payableAmount
            )
        }

        // Step 9: Verification Guard
        val grandTotal = results.sumOf { it.amount }
        val discrepancy = abs(grandTotal - totalCost)
        // Allow a microscopic floating-point epsilon (e.g. 0.01) to prevent false positives while remaining strict.
        if (discrepancy > 0.01) {
            throw CalculationException(
                "Verification Guard Failed! Grand Total sum ($grandTotal) does not equal expected total cost ($totalCost). Discrepancy: $discrepancy."
            )
        }

        return results
    }
}
