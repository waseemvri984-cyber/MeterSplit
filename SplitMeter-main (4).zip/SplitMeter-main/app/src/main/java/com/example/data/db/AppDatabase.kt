package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.domain.model.*

@Database(
    entities = [
        Member::class,
        BillingCycle::class,
        Reading::class,
        MemberResult::class,
        AuditLog::class,
        Setting::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun memberDao(): MemberDao
    abstract fun billingCycleDao(): BillingCycleDao
    abstract fun readingDao(): ReadingDao
    abstract fun memberResultDao(): MemberResultDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun settingDao(): SettingDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "metersplit_database"
                )
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed default settings precisely
                        db.execSQL("INSERT INTO settings (`key`, `value`) VALUES ('default_fixed_charge', '1500.0')")
                        db.execSQL("INSERT INTO settings (`key`, `value`) VALUES ('currency', 'Rs.')")
                        db.execSQL("INSERT INTO settings (`key`, `value`) VALUES ('decimals', '2')")

                        // Seed a few default members for a functional out-of-the-box wizard experience
                        db.execSQL("INSERT INTO members (name, weeklyHours, displayOrder, isActive) VALUES ('Alice Miller', 40.0, 1, 1)")
                        db.execSQL("INSERT INTO members (name, weeklyHours, displayOrder, isActive) VALUES ('Bob Smith', 32.0, 2, 1)")
                        db.execSQL("INSERT INTO members (name, weeklyHours, displayOrder, isActive) VALUES ('Charlie Davis', 48.0, 3, 1)")
                        db.execSQL("INSERT INTO members (name, weeklyHours, displayOrder, isActive) VALUES ('Diana Prince', 48.0, 4, 1)")
                    }
                })
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
