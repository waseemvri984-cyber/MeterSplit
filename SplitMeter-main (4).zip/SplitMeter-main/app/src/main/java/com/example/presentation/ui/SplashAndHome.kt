package com.example.presentation.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.drawText
import java.util.Locale
import kotlin.math.ceil
import com.example.domain.model.BillingCycle
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onNavigateToHome: () -> Unit) {
    var visible by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        visible = true
        delay(2000)
        onNavigateToHome()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primaryContainer,
                        MaterialTheme.colorScheme.surface
                    )
                )
            )
            .testTag("splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(animationSpec = tween(1000)) + scaleIn(animationSpec = tween(1000)),
            exit = fadeOut(animationSpec = tween(500))
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(24.dp)
            ) {
                // Meter Graphic Circle
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .clip(RoundedCornerShape(32.dp))
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ElectricBolt,
                        contentDescription = "Meter Logo",
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(64.dp)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "MeterSplit",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Deterministic Sub-Meter Billing Engine",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        letterSpacing = 0.5.sp
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(48.dp))

                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.primary,
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(40.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    recentCycle: BillingCycle?,
    allCycles: List<BillingCycle> = emptyList(),
    currency: String = "Rs.",
    onStartWizard: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToMembers: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToAudit: () -> Unit,
    onNavigateToAbout: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.ElectricBolt,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "MeterSplit",
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = Modifier.testTag("home_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero / Recent Status Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    if (recentCycle != null) {
                        Text(
                            text = "Latest Billing Cycle",
                            style = MaterialTheme.typography.labelLarge.copy(
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${recentCycle.month} ${recentCycle.year}",
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Amount: Rs. ${recentCycle.billAmount + recentCycle.additionalFixedCharge}",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                            Surface(
                                shape = CircleShape,
                                color = if (recentCycle.status == "Locked") Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.align(Alignment.CenterVertically)
                            ) {
                                Text(
                                    text = recentCycle.status,
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "Welcome to MeterSplit!",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Start a step-by-step wizard to split electricity/utility bill units amongst members based on weekly hours and individual sub-meter readings.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }

            // Primary Wizard FAB/Button
            Button(
                onClick = onStartWizard,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .testTag("start_wizard_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "New Billing Cycle Wizard",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            BillHistoryChart(allCycles = allCycles, currency = currency)

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Management & Logs",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )

            // Grid Layout for shortcuts
            ShortcutItem(
                title = "Billing History",
                description = "Search, view, lock/unlock, recalculate, or delete past billing cycles",
                icon = Icons.Default.History,
                onClick = onNavigateToHistory,
                tag = "history_shortcut"
            )

            ShortcutItem(
                title = "Manage Members",
                description = "Configure active members, tenants, and weekly hours (out of 168 hours)",
                icon = Icons.Default.People,
                onClick = onNavigateToMembers,
                tag = "members_shortcut"
            )

            ShortcutItem(
                title = "Operational Audits",
                description = "Review timestamped transaction summaries and audit logs of critical changes",
                icon = Icons.Default.Shield,
                onClick = onNavigateToAudit,
                tag = "audit_shortcut"
            )

            ShortcutItem(
                title = "System Settings",
                description = "Customize currencies, decimal precision, and default additional fixed charges",
                icon = Icons.Default.Settings,
                onClick = onNavigateToSettings,
                tag = "settings_shortcut"
            )

            ShortcutItem(
                title = "About MeterSplit",
                description = "System metadata, architecture stack, and engine algorithms",
                icon = Icons.Default.Info,
                onClick = onNavigateToAbout,
                tag = "about_shortcut"
            )
        }
    }
}

@Composable
fun ShortcutItem(
    title: String,
    description: String,
    icon: ImageVector,
    onClick: () -> Unit,
    tag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(tag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

data class ChartDataPoint(
    val label: String,
    val amount: Float,
    val monthName: String,
    val year: Int,
    val isDemo: Boolean = false
)

@Composable
fun BillHistoryChart(
    allCycles: List<BillingCycle>,
    currency: String,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()
    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary
    val onSurfaceVariant = MaterialTheme.colorScheme.onSurfaceVariant
    val onSurfaceColor = MaterialTheme.colorScheme.onSurface
    val gridColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
    
    // Parse month to number helper
    fun getMonthNumber(monthName: String): Int {
        return when (monthName.trim()) {
            "January" -> 1
            "February" -> 2
            "March" -> 3
            "April" -> 4
            "May" -> 5
            "June" -> 6
            "July" -> 7
            "August" -> 8
            "September" -> 9
            "October" -> 10
            "November" -> 11
            "December" -> 12
            else -> 1
        }
    }

    // Process cycles into last 6 months chronological
    val chartData = remember(allCycles) {
        if (allCycles.isEmpty()) {
            // High fidelity realistic demo data
            listOf(
                ChartDataPoint("Nov '25", 4200f, "November", 2025, true),
                ChartDataPoint("Dec '25", 5800f, "December", 2025, true),
                ChartDataPoint("Jan '26", 4900f, "January", 2026, true),
                ChartDataPoint("Feb '26", 6200f, "February", 2026, true),
                ChartDataPoint("Mar '26", 5100f, "March", 2026, true),
                ChartDataPoint("Apr '26", 7100f, "April", 2026, true)
            )
        } else {
            val sorted = allCycles.sortedWith(compareBy<BillingCycle> { it.year }.thenBy { getMonthNumber(it.month) })
            val last6 = sorted.takeLast(6)
            last6.map { cycle ->
                val shortMonth = cycle.month.take(3)
                val shortYear = cycle.year.toString().takeLast(2)
                ChartDataPoint(
                    label = "$shortMonth '$shortYear'",
                    amount = (cycle.billAmount + cycle.additionalFixedCharge).toFloat(),
                    monthName = cycle.month,
                    year = cycle.year,
                    isDemo = false
                )
            }
        }
    }

    val isDemo = chartData.firstOrNull()?.isDemo == true
    val averageBill = remember(chartData) {
        if (chartData.isEmpty()) 0f else chartData.map { it.amount }.average().toFloat()
    }
    
    var selectedIndex by remember { mutableStateOf<Int?>(null) }
    
    // Automatically reset selection if data changes
    LaunchedEffect(chartData) {
        selectedIndex = null
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("bill_history_chart_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Expense History Trends",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (isDemo) "Previewing mock trends" else "Actual billing engine telemetry",
                        style = MaterialTheme.typography.bodySmall,
                        color = onSurfaceVariant
                    )
                }
                
                // Demo indicator badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isDemo) {
                        MaterialTheme.colorScheme.secondaryContainer
                    } else {
                        MaterialTheme.colorScheme.primaryContainer
                    },
                    modifier = Modifier.align(Alignment.CenterVertically)
                ) {
                    Text(
                        text = if (isDemo) "DEMO PREVIEW" else "LIVE DATA",
                        color = if (isDemo) {
                            MaterialTheme.colorScheme.onSecondaryContainer
                        } else {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        },
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Summary stats banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "6-Month Average",
                        style = MaterialTheme.typography.labelMedium,
                        color = onSurfaceVariant
                    )
                    Text(
                        text = String.format(Locale.US, "%s %,.2f", currency, averageBill),
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Peak Charge",
                        style = MaterialTheme.typography.labelMedium,
                        color = onSurfaceVariant
                    )
                    val peakAmount = chartData.maxOfOrNull { it.amount } ?: 0f
                    val peakLabel = chartData.firstOrNull { it.amount == peakAmount }?.label ?: ""
                    Text(
                        text = String.format(Locale.US, "%s %,.0f (%s)", currency, peakAmount, peakLabel),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Chart Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(chartData) {
                            detectTapGestures { offset ->
                                val leftPadding = 45.dp.toPx()
                                val rightPadding = 15.dp.toPx()
                                val bottomPadding = 30.dp.toPx()
                                val drawWidth = size.width - leftPadding - rightPadding
                                val barSpacing = drawWidth / chartData.size
                                
                                if (offset.x >= leftPadding && offset.x <= size.width - rightPadding) {
                                    val colIndex = ((offset.x - leftPadding) / barSpacing).toInt().coerceIn(0, chartData.size - 1)
                                    selectedIndex = if (selectedIndex == colIndex) null else colIndex
                                } else {
                                    selectedIndex = null
                                }
                            }
                        }
                ) {
                    val leftPadding = 45.dp.toPx()
                    val rightPadding = 15.dp.toPx()
                    val bottomPadding = 30.dp.toPx()
                    val topPadding = 20.dp.toPx()
                    
                    val drawWidth = size.width - leftPadding - rightPadding
                    val drawHeight = size.height - topPadding - bottomPadding
                    
                    val maxVal = chartData.maxOfOrNull { it.amount }?.coerceAtLeast(100f) ?: 100f
                    // Nice rounded max
                    val roundedMax = if (maxVal <= 10f) 10f
                    else if (maxVal <= 100f) ceil(maxVal / 10f) * 10f
                    else if (maxVal <= 1000f) ceil(maxVal / 100f) * 100f
                    else ceil(maxVal / 1000f) * 1000f
                    
                    val barSpacing = drawWidth / chartData.size
                    val barWidth = barSpacing * 0.55f
                    
                    // Draw horizontal dashed grid lines & Y-Axis labels
                    val steps = 4
                    for (step in 0 until steps) {
                        val fraction = step / (steps - 1f)
                        val y = size.height - bottomPadding - (fraction * drawHeight)
                        
                        // Grid Line
                        drawLine(
                            color = gridColor,
                            start = Offset(leftPadding, y),
                            end = Offset(size.width - rightPadding, y),
                            strokeWidth = 1.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                        )
                        
                        // Y-Axis label
                        val valAtStep = fraction * roundedMax
                        val labelText = if (valAtStep >= 1000) {
                            String.format(Locale.US, "%.1fk", valAtStep / 1000f).replace(".0", "")
                        } else {
                            String.format(Locale.US, "%.0f", valAtStep)
                        }
                        
                        val textLayout = textMeasurer.measure(
                            text = labelText,
                            style = TextStyle(fontSize = 9.sp)
                        )
                        val labelX = leftPadding - textLayout.size.width - 6.dp.toPx()
                        val labelY = y - (textLayout.size.height / 2f)
                        
                        drawText(
                            textMeasurer = textMeasurer,
                            text = labelText,
                            style = TextStyle(
                                color = onSurfaceVariant.copy(alpha = 0.8f),
                                fontSize = 9.sp,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                            ),
                            topLeft = Offset(labelX, labelY)
                        )
                    }
                    
                    // Draw Bars & X-Axis labels
                    chartData.forEachIndexed { i, item ->
                        val barHeightFrac = item.amount / roundedMax
                        val barHeight = barHeightFrac * drawHeight
                        val barTop = size.height - bottomPadding - barHeight
                        val barLeft = leftPadding + (i * barSpacing) + (barSpacing - barWidth) / 2f
                        
                        // Draw selection highlight background column if selected
                        if (selectedIndex == i) {
                            drawRect(
                                color = primaryColor.copy(alpha = 0.06f),
                                topLeft = Offset(leftPadding + i * barSpacing, topPadding),
                                size = Size(barSpacing, drawHeight)
                            )
                        }

                        // Create beautiful rounded top path for each bar
                        val path = Path().apply {
                            val r = 6.dp.toPx().coerceAtMost(barWidth / 2f)
                            moveTo(barLeft, size.height - bottomPadding)
                            lineTo(barLeft, barTop + r)
                            quadraticTo(barLeft, barTop, barLeft + r, barTop)
                            lineTo(barLeft + barWidth - r, barTop)
                            quadraticTo(barLeft + barWidth, barTop, barLeft + barWidth, barTop + r)
                            lineTo(barLeft + barWidth, size.height - bottomPadding)
                            close()
                        }
                        
                        drawPath(
                            path = path,
                            brush = Brush.verticalGradient(
                                colors = if (item.isDemo) {
                                    if (selectedIndex == i) {
                                        listOf(secondaryColor.copy(alpha = 0.6f), secondaryColor.copy(alpha = 0.3f))
                                    } else {
                                        listOf(secondaryColor.copy(alpha = 0.4f), secondaryColor.copy(alpha = 0.15f))
                                    }
                                } else {
                                    if (selectedIndex == i) {
                                        listOf(primaryColor, primaryColor.copy(alpha = 0.7f))
                                    } else {
                                        listOf(primaryColor.copy(alpha = 0.85f), primaryColor.copy(alpha = 0.5f))
                                    }
                                }
                            )
                        )
                        
                        // Draw outline around selected bar
                        if (selectedIndex == i) {
                            drawPath(
                                path = path,
                                color = if (item.isDemo) secondaryColor else primaryColor,
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5.dp.toPx())
                            )
                        }

                        // Top value text
                        val valueText = if (item.amount >= 1000f) {
                            String.format(Locale.US, "%.1fk", item.amount / 1000f).replace(".0", "")
                        } else {
                            String.format(Locale.US, "%.0f", item.amount)
                        }
                        
                        val valueLayout = textMeasurer.measure(
                            text = valueText,
                            style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        )
                        
                        val valX = barLeft + (barWidth / 2f) - (valueLayout.size.width / 2f)
                        val valY = barTop - valueLayout.size.height - 4.dp.toPx()
                        
                        if (valY >= 0) {
                            drawText(
                                textMeasurer = textMeasurer,
                                text = valueText,
                                style = TextStyle(
                                    color = if (selectedIndex == i) {
                                        if (item.isDemo) secondaryColor else primaryColor
                                    } else {
                                        if (item.isDemo) secondaryColor.copy(alpha = 0.6f) else primaryColor.copy(alpha = 0.8f)
                                    },
                                    fontSize = 9.sp,
                                    fontWeight = if (selectedIndex == i) FontWeight.ExtraBold else FontWeight.Bold
                                ),
                                topLeft = Offset(valX, valY)
                            )
                        }
                        
                        // X-Axis Label
                        val xLabelLayout = textMeasurer.measure(
                            text = item.label,
                            style = TextStyle(fontSize = 9.sp)
                        )
                        val xlX = barLeft + (barWidth / 2f) - (xLabelLayout.size.width / 2f)
                        val xlY = size.height - bottomPadding + 8.dp.toPx()
                        
                        drawText(
                            textMeasurer = textMeasurer,
                            text = item.label,
                            style = TextStyle(
                                color = if (selectedIndex == i) {
                                    onSurfaceColor
                                } else {
                                    onSurfaceVariant
                                },
                                fontSize = 9.sp,
                                fontWeight = if (selectedIndex == i) FontWeight.Bold else FontWeight.Medium
                            ),
                            topLeft = Offset(xlX, xlY)
                        )
                    }
                }
            }
            
            // Selected bar detail feedback helper
            AnimatedVisibility(
                visible = selectedIndex != null,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                selectedIndex?.let { index ->
                    if (index in chartData.indices) {
                        val item = chartData[index]
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (item.isDemo) {
                                        MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
                                    } else {
                                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                                    }
                                )
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = if (item.isDemo) secondaryColor else primaryColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${item.monthName} ${item.year}",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            
                            Text(
                                text = String.format(Locale.US, "Total Bill: %s %,.2f", currency, item.amount),
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.ExtraBold),
                                color = if (item.isDemo) secondaryColor else primaryColor
                            )
                        }
                    }
                }
            }
            
            if (selectedIndex == null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "💡 Tap any bar above to view detailed expenses for that month.",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                    color = onSurfaceVariant.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
