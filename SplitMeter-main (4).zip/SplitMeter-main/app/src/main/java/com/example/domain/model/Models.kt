package com.example.domain.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "members")
data class Member(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val weeklyHours: Double,
    val displayOrder: Int,
    val isActive: Boolean = true
) : Serializable

@Entity(tableName = "billing_cycles")
data class BillingCycle(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val month: String,
    val year: Int,
    val billAmount: Double,
    val additionalFixedCharge: Double,
    val billUnits: Double,
    val firstOn: Double,
    val status: String, // 'Draft', 'Locked', 'Unlocked'
    val createdAt: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "readings")
data class Reading(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val billingId: Int,
    val sequence: Int,
    val memberId: Int,
    val onReading: Double,
    val offReading: Double,
    val units: Double
) : Serializable

@Entity(tableName = "member_results")
data class MemberResult(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val billingId: Int,
    val memberId: Int,
    val recordedUnits: Double,
    val adjustmentUnits: Double,
    val effectiveUnits: Double,
    val amount: Double
) : Serializable

@Entity(tableName = "audit_log")
data class AuditLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val billingId: Int?,
    val action: String,
    val description: String,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "settings")
data class Setting(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val key: String,
    val value: String
) : Serializable
