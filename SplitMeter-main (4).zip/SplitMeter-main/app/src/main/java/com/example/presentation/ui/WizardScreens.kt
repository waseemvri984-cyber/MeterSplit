package com.example.presentation.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.Member
import com.example.presentation.viewmodel.ReadingItemState
import com.example.presentation.viewmodel.WizardUIState
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WizardContainer(
    state: WizardUIState,
    onStep1Update: (String, Int, Double, Double, Double, Double) -> Unit,
    onProceedStep1: () -> Unit,
    onUpdateReading: (Int?, Double) -> Unit,
    onNextReading: () -> Unit,
    onPrevReading: () -> Unit,
    onUndoReading: () -> Unit,
    onFinishReadings: () -> Unit,
    onBackToReadings: () -> Unit,
    onCalculate: () -> Unit,
    onCloseWizard: () -> Unit,
    currency: String = "Rs.",
    decimals: Int = 2
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Split Billing Wizard",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Step ${state.currentStep} of 4: " + when (state.currentStep) {
                                1 -> "Billing Input"
                                2 -> "Reading Entry"
                                3 -> "Overview Review"
                                4 -> "Split Results"
                                else -> ""
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onCloseWizard) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (state.currentStep) {
                1 -> Step1InputScreen(
                    state = state,
                    onUpdateFields = onStep1Update,
                    onNext = onProceedStep1
                )
                2 -> Step2ReadingsScreen(
                    state = state,
                    onUpdateReading = onUpdateReading,
                    onNext = onNextReading,
                    onPrev = onPrevReading,
                    onUndo = onUndoReading,
                    onFinish = onFinishReadings
                )
                3 -> Step3ReviewScreen(
                    state = state,
                    onBack = onBackToReadings,
                    onCalculate = onCalculate,
                    currency = currency,
                    decimals = decimals
                )
                4 -> Step4ResultsScreen(
                    state = state,
                    onFinish = onCloseWizard,
                    currency = currency,
                    decimals = decimals
                )
            }

            if (state.isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.3f)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
        }
    }
}

// ========================================================
// STEP 1: NEW BILLING INPUT SCREEN
// ========================================================
@Composable
fun Step1InputScreen(
    state: WizardUIState,
    onUpdateFields: (String, Int, Double, Double, Double, Double) -> Unit,
    onNext: () -> Unit
) {
    val monthNames = listOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )

    var monthMenuExpanded by remember { mutableStateOf(false) }

    // Form inputs stateholders
    var billAmountStr by remember { mutableStateOf(if (state.billAmount > 0) state.billAmount.toString() else "") }
    var billUnitsStr by remember { mutableStateOf(if (state.billUnits > 0) state.billUnits.toString() else "") }
    var firstOnStr by remember { mutableStateOf(if (state.firstOn > 0) state.firstOn.toString() else "") }
    var fixedChargeStr by remember { mutableStateOf(state.additionalFixedCharge.toString()) }
    var yearStr by remember { mutableStateOf(state.year.toString()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("step1_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Enter Core Billing Parameters",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Capture billing timeline and core costs as requested on the physical/master invoice.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Month Selection
        item {
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = state.month,
                    onValueChange = {},
                    label = { Text("Billing Month") },
                    readOnly = true,
                    trailingIcon = {
                        IconButton(onClick = { monthMenuExpanded = true }) {
                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Select Month")
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { monthMenuExpanded = true }
                        .testTag("billing_month_field")
                )
                DropdownMenu(
                    expanded = monthMenuExpanded,
                    onDismissRequest = { monthMenuExpanded = false },
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    monthNames.forEach { m ->
                        DropdownMenuItem(
                            text = { Text(m) },
                            onClick = {
                                onUpdateFields(
                                    m,
                                    yearStr.toIntOrNull() ?: state.year,
                                    billAmountStr.toDoubleOrNull() ?: 0.0,
                                    billUnitsStr.toDoubleOrNull() ?: 0.0,
                                    firstOnStr.toDoubleOrNull() ?: 0.0,
                                    fixedChargeStr.toDoubleOrNull() ?: 0.0
                                )
                                monthMenuExpanded = false
                            }
                        )
                    }
                }
            }
        }

        // Year Selection
        item {
            OutlinedTextField(
                value = yearStr,
                onValueChange = {
                    yearStr = it
                    onUpdateFields(
                        state.month,
                        it.toIntOrNull() ?: 0,
                        billAmountStr.toDoubleOrNull() ?: 0.0,
                        billUnitsStr.toDoubleOrNull() ?: 0.0,
                        firstOnStr.toDoubleOrNull() ?: 0.0,
                        fixedChargeStr.toDoubleOrNull() ?: 0.0
                    )
                },
                label = { Text("Billing Year") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("billing_year_field")
            )
        }

        // Bill Amount
        item {
            OutlinedTextField(
                value = billAmountStr,
                onValueChange = {
                    billAmountStr = it
                    onUpdateFields(
                        state.month,
                        yearStr.toIntOrNull() ?: state.year,
                        it.toDoubleOrNull() ?: 0.0,
                        billUnitsStr.toDoubleOrNull() ?: state.billUnits,
                        firstOnStr.toDoubleOrNull() ?: state.firstOn,
                        fixedChargeStr.toDoubleOrNull() ?: state.additionalFixedCharge
                    )
                },
                label = { Text("Master Bill Amount") },
                placeholder = { Text("e.g. 12500.00") },
                prefix = { Text("Rs. ") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("bill_amount_field")
            )
        }

        // Bill Units
        item {
            OutlinedTextField(
                value = billUnitsStr,
                onValueChange = {
                    billUnitsStr = it
                    onUpdateFields(
                        state.month,
                        yearStr.toIntOrNull() ?: state.year,
                        billAmountStr.toDoubleOrNull() ?: state.billAmount,
                        it.toDoubleOrNull() ?: 0.0,
                        firstOnStr.toDoubleOrNull() ?: state.firstOn,
                        fixedChargeStr.toDoubleOrNull() ?: state.additionalFixedCharge
                    )
                },
                label = { Text("Master Bill Units Consumed") },
                placeholder = { Text("e.g. 450.0") },
                suffix = { Text("kWh") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("bill_units_field")
            )
        }

        // First ON Reading
        item {
            OutlinedTextField(
                value = firstOnStr,
                onValueChange = {
                    firstOnStr = it
                    onUpdateFields(
                        state.month,
                        yearStr.toIntOrNull() ?: state.year,
                        billAmountStr.toDoubleOrNull() ?: state.billAmount,
                        billUnitsStr.toDoubleOrNull() ?: state.billUnits,
                        it.toDoubleOrNull() ?: 0.0,
                        fixedChargeStr.toDoubleOrNull() ?: state.additionalFixedCharge
                    )
                },
                label = { Text("First ON Reading (Initial Sub-meter value)") },
                placeholder = { Text("e.g. 1024.5") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("first_on_field")
            )
        }

        // Additional Fixed Charge (prefilled)
        item {
            OutlinedTextField(
                value = fixedChargeStr,
                onValueChange = {
                    fixedChargeStr = it
                    onUpdateFields(
                        state.month,
                        yearStr.toIntOrNull() ?: state.year,
                        billAmountStr.toDoubleOrNull() ?: state.billAmount,
                        billUnitsStr.toDoubleOrNull() ?: state.billUnits,
                        firstOnStr.toDoubleOrNull() ?: state.firstOn,
                        it.toDoubleOrNull() ?: 0.0
                    )
                },
                label = { Text("Additional Fixed Charges (Maintenance, service, etc.)") },
                prefix = { Text("Rs. ") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("additional_charge_field")
            )
        }

        // Error message view
        if (state.errorMessage != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Error, contentDescription = "Error", tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = state.errorMessage, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        // Proceed Button
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onNext,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("next_step1_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(text = "Proceed to Readings", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null)
            }
        }
    }
}

// ========================================================
// STEP 2: READING ENTRY SCREEN
// ========================================================
@Composable
fun Step2ReadingsScreen(
    state: WizardUIState,
    onUpdateReading: (Int?, Double) -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onUndo: () -> Unit,
    onFinish: () -> Unit
) {
    val currentIndex = state.currentReadingIndex
    val currentReading = state.readings.getOrNull(currentIndex) ?: ReadingItemState(sequence = currentIndex + 1)

    var memberMenuExpanded by remember { mutableStateOf(false) }
    var searchMemberQuery by remember { mutableStateOf("") }
    var offReadingStr by remember { mutableStateOf(if (currentReading.offReading > 0) currentReading.offReading.toString() else "") }

    // Clean sync local state whenever reading index shifts
    LaunchedEffect(currentIndex) {
        offReadingStr = if (currentReading.offReading > 0) currentReading.offReading.toString() else ""
    }

    // Filter active members based on search query
    val filteredMembers = state.members.filter {
        it.isActive && it.name.contains(searchMemberQuery, ignoreCase = true)
    }

    val selectedMember = state.members.firstOrNull { it.id == currentReading.memberId }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("step2_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Reading Sequence #${currentReading.sequence}",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.testTag("reading_sequence_header")
                )
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                ) {
                    Text(
                        text = "Total Entries: ${state.readings.size}",
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Each sub-meter has a sequential interval. Enter the off-reading values for each tenant.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Searchable Member Selector Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardBorder(BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Assign Tenant Member",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = selectedMember?.name ?: "Tap to Select Member",
                            onValueChange = {},
                            readOnly = true,
                            leadingIcon = { Icon(imageVector = Icons.Default.Person, contentDescription = null) },
                            trailingIcon = {
                                IconButton(onClick = { memberMenuExpanded = true }) {
                                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Dropdown")
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { memberMenuExpanded = true }
                                .testTag("select_member_dropdown_trigger")
                        )

                        DropdownMenu(
                            expanded = memberMenuExpanded,
                            onDismissRequest = { memberMenuExpanded = false },
                            modifier = Modifier.fillMaxWidth(0.85f)
                        ) {
                            // Search Box inside Dropdown for "searchable member dropdown" requirement
                            OutlinedTextField(
                                value = searchMemberQuery,
                                onValueChange = { searchMemberQuery = it },
                                label = { Text("Search Member") },
                                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp)
                                    .testTag("member_dropdown_search")
                            )

                            if (filteredMembers.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("No members found") },
                                    onClick = {},
                                    enabled = false
                                )
                            } else {
                                filteredMembers.forEach { member ->
                                    DropdownMenuItem(
                                        text = {
                                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                                Text(member.name, fontWeight = FontWeight.Bold)
                                                Text("${member.weeklyHours} hrs/wk", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        },
                                        onClick = {
                                            onUpdateReading(member.id, offReadingStr.toDoubleOrNull() ?: 0.0)
                                            memberMenuExpanded = false
                                            searchMemberQuery = ""
                                        },
                                        modifier = Modifier.testTag("dropdown_member_item_${member.id}")
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Live Reading Parameters Cards
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // ON Reading (Prefilled or Auto-filled)
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "ON Reading:", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            text = String.format("%.2f", currentReading.onReading),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.testTag("on_reading_indicator")
                        )
                    }

                    Divider(color = MaterialTheme.colorScheme.outlineVariant)

                    // OFF Reading Input field
                    OutlinedTextField(
                        value = offReadingStr,
                        onValueChange = {
                            offReadingStr = it
                            onUpdateReading(currentReading.memberId, it.toDoubleOrNull() ?: 0.0)
                        },
                        label = { Text("OFF Reading Value") },
                        placeholder = { Text("Enter current OFF count") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("off_reading_input")
                    )

                    Divider(color = MaterialTheme.colorScheme.outlineVariant)

                    // Live Units Indicator
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "Live Calculated Units:", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            text = String.format("%.2f kWh", (offReadingStr.toDoubleOrNull() ?: 0.0) - currentReading.onReading).coerceAtLeast("0.00 kWh"),
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                            color = if ((offReadingStr.toDoubleOrNull() ?: 0.0) >= currentReading.onReading) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
                            modifier = Modifier.testTag("live_units_indicator")
                        )
                    }
                }
            }
        }

        // Error message view
        if (state.errorMessage != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Error, contentDescription = "Error", tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = state.errorMessage, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        // Action Buttons Grid
        item {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Previous Reading
                    Button(
                        onClick = onPrev,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("previous_reading_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer)
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Prev")
                    }

                    // Next Reading / Add sequence (autosaves progress)
                    Button(
                        onClick = onNext,
                        modifier = Modifier
                            .weight(1.2f)
                            .height(52.dp)
                            .testTag("next_reading_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Next Reading", fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(imageVector = Icons.Default.Add, contentDescription = null)
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Undo Last Entry
                    OutlinedButton(
                        onClick = onUndo,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("undo_reading_button"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Icon(imageVector = Icons.Default.Undo, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Undo Entry")
                    }

                    // Finish readings -> review
                    Button(
                        onClick = onFinish,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("finish_readings_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                    ) {
                        Text("Review splits")
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(imageVector = Icons.Default.FactCheck, contentDescription = null)
                    }
                }
            }
        }
    }
}

private fun Double.coerceAtLeast(defaultValue: String): String {
    return if (this < 0) defaultValue else String.format("%.2f kWh", this)
}

// ========================================================
// STEP 3: REVIEW / OVERVIEW SCREEN
// ========================================================
@Composable
fun Step3ReviewScreen(
    state: WizardUIState,
    onBack: () -> Unit,
    onCalculate: () -> Unit,
    currency: String,
    decimals: Int
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("step3_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Verification & Review Overview",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Please verify the following readings before running calculations on the MeterSplit engine.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Summary Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "Invoice Details", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Master Amount:")
                        Text("$currency ${String.format("%.2f", state.billAmount)}")
                    }
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Fixed Charge:")
                        Text("$currency ${String.format("%.2f", state.additionalFixedCharge)}")
                    }
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Bill Units:")
                        Text("${String.format("%.2f", state.billUnits)} kWh")
                    }
                    Divider()
                    val totalReadingsUnits = state.readings.sumOf { it.units }
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Recorded Units sum:")
                        Text("${String.format("%.2f", totalReadingsUnits)} kWh")
                    }
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Adjustment Units:")
                        Text("${String.format("%.2f", state.billUnits - totalReadingsUnits)} kWh", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Text(text = "Entered Sub-meter Readings", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
        }

        // Readings table items
        items(state.readings) { r ->
            val memberName = state.members.firstOrNull { it.id == r.memberId }?.name ?: "Unknown"
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardBorder(BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant))
            ) {
                Row(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Seq #${r.sequence} - $memberName", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        Text(text = "ON: ${String.format("%.2f", r.onReading)} | OFF: ${String.format("%.2f", r.offReading)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer
                    ) {
                        Text(
                            text = "${String.format("%.2f", r.units)} kWh",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // Errors display
        if (state.errorMessage != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = state.errorMessage, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        // Bottom Navigation/Calculate action triggers
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onBack,
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                        .testTag("back_to_readings_button")
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Modify Readings")
                }

                Button(
                    onClick = onCalculate,
                    modifier = Modifier
                        .weight(1.2f)
                        .height(56.dp)
                        .testTag("calculate_splits_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Finalize Splits", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ========================================================
// STEP 4: RESULTS SCREEN
// ========================================================
@Composable
fun Step4ResultsScreen(
    state: WizardUIState,
    onFinish: () -> Unit,
    currency: String,
    decimals: Int
) {
    val totalCost = state.billAmount + state.additionalFixedCharge
    val sumSplits = state.results.sumOf { it.amount }
    val difference = abs(sumSplits - totalCost)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("step4_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF2E7D32),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Deterministic Calculation Finalized",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "The MeterSplit engine verified all splits mathematically with 100% precision.",
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                }
            }
        }

        // Bill Summary stats
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Bill Amount", style = MaterialTheme.typography.labelSmall)
                        Text("$currency ${String.format("%.2f", state.billAmount)}", fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Fixed Charge", style = MaterialTheme.typography.labelSmall)
                        Text("$currency ${String.format("%.2f", state.additionalFixedCharge)}", fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Total Split", style = MaterialTheme.typography.labelSmall)
                        Text("$currency ${String.format("%.2f", totalCost)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        item {
            Text(
                text = "Payable Shares by Member",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        // Render each member share card
        items(state.results) { res ->
            val member = state.members.firstOrNull { it.id == res.memberId }
            val memberName = member?.name ?: "Unknown Member"
            val weeklyHours = member?.weeklyHours ?: 0.0

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                border = CardBorder(BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Text(text = memberName, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Text(text = "Hours: $weeklyHours hrs/wk | Adjust Share: ${String.format("%.3f", res.adjustmentUnits)} kWh", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(
                            text = "$currency ${String.format("%.2f", res.amount)}",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.testTag("payable_amount_member_${res.memberId}")
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Recorded Units", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${String.format("%.2f", res.recordedUnits)} kWh", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Effective Units", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${String.format("%.2f", res.effectiveUnits)} kWh", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Unit Rate", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("$currency ${String.format("%.3f", totalCost / state.billUnits)}", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }

        // Strict verification guard footer (must prove zero discrepancy)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                border = CardBorder(BorderStroke(1.dp, Color(0xFF81C784)))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Verified, contentDescription = "Verified", tint = Color(0xFF2E7D32))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Verification: Split difference equals zero!",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color(0xFF1B5E20),
                            modifier = Modifier.testTag("verification_status")
                        )
                        Text(
                            text = "Discrepancy: ${String.format("%.5f", difference)} (Grand Total sum perfectly offsets costs)",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF2E7D32)
                        )
                    }
                }
            }
        }

        // Complete Wizard button
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onFinish,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("finish_wizard_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(text = "Complete & Close Wizard", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}

// Custom implementation helper for clean border styling
@Composable
fun CardBorder(border: BorderStroke): BorderStroke = border
