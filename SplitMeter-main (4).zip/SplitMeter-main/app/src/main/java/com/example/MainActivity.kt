package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.presentation.ui.*
import com.example.presentation.viewmodel.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val app = application as MeterSplitApplication
            val repository = app.repository

            // Instantiate ViewModels using the custom Factories
            val wizardViewModel: WizardViewModel = viewModel(
                factory = WizardViewModelFactory(repository)
            )
            val membersViewModel: MembersViewModel = viewModel(
                factory = AppViewModelFactory(repository)
            )
            val settingsViewModel: SettingsViewModel = viewModel(
                factory = AppViewModelFactory(repository)
            )
            val auditViewModel: AuditViewModel = viewModel(
                factory = AppViewModelFactory(repository)
            )
            val historyViewModel: HistoryViewModel = viewModel(
                factory = AppViewModelFactory(repository)
            )

            MyApplicationTheme {
                AppNavigation(
                    wizardViewModel = wizardViewModel,
                    membersViewModel = membersViewModel,
                    settingsViewModel = settingsViewModel,
                    auditViewModel = auditViewModel,
                    historyViewModel = historyViewModel
                )
            }
        }
    }
}

@Composable
fun AppNavigation(
    wizardViewModel: WizardViewModel,
    membersViewModel: MembersViewModel,
    settingsViewModel: SettingsViewModel,
    auditViewModel: AuditViewModel,
    historyViewModel: HistoryViewModel
) {
    val navController = rememberNavController()

    // Observe dynamic settings for formatting
    val settingsMap by settingsViewModel.settings.collectAsState()
    val currency = settingsMap["currency"] ?: "Rs."
    val decimals = settingsMap["decimals"]?.toIntOrNull() ?: 2

    // Observe billing cycles to find the latest for the Home hero card
    val cycles by historyViewModel.billingCycles.collectAsState()
    val recentCycle = cycles.firstOrNull()

    NavHost(
        navController = navController,
        startDestination = "splash",
        modifier = Modifier.fillMaxSize()
    ) {
        // Splash Screen
        composable("splash") {
            SplashScreen(
                onNavigateToHome = {
                    navController.navigate("home") {
                        popUpTo("splash") { inclusive = true }
                    }
                }
            )
        }

        // Home Screen Dashboard
        composable("home") {
            HomeScreen(
                recentCycle = recentCycle,
                allCycles = cycles,
                currency = currency,
                onStartWizard = {
                    wizardViewModel.resetWizard()
                    navController.navigate("wizard")
                },
                onNavigateToHistory = {
                    historyViewModel.clearMessages()
                    navController.navigate("history")
                },
                onNavigateToMembers = {
                    navController.navigate("members")
                },
                onNavigateToSettings = {
                    navController.navigate("settings")
                },
                onNavigateToAudit = {
                    navController.navigate("audit")
                },
                onNavigateToAbout = {
                    navController.navigate("about")
                }
            )
        }

        // Multi-Step Wizard Container
        composable("wizard") {
            val wizardState by wizardViewModel.uiState.collectAsState()
            WizardContainer(
                state = wizardState,
                onStep1Update = { month, year, amount, units, firstOn, fixedCharge ->
                    wizardViewModel.updateStep1Fields(month, year, amount, units, firstOn, fixedCharge)
                },
                onProceedStep1 = {
                    wizardViewModel.proceedFromStep1()
                },
                onUpdateReading = { memberId, offReading ->
                    wizardViewModel.updateCurrentReading(memberId, offReading)
                },
                onNextReading = {
                    wizardViewModel.nextReading()
                },
                onPrevReading = {
                    wizardViewModel.previousReading()
                },
                onUndoReading = {
                    wizardViewModel.undoLastReading()
                },
                onFinishReadings = {
                    wizardViewModel.finishReadings()
                },
                onBackToReadings = {
                    wizardViewModel.backToReadings()
                },
                onCalculate = {
                    wizardViewModel.calculateAndShowResults()
                },
                onCloseWizard = {
                    navController.popBackStack()
                },
                currency = currency,
                decimals = decimals
            )
        }

        // Standalone Results view (re-uses wizard step 4 view)
        composable("results/{cycleId}") { backStackEntry ->
            val cycleId = backStackEntry.arguments?.getString("cycleId")?.toIntOrNull() ?: 0
            val wizardState by wizardViewModel.uiState.collectAsState()

            // When entering standalone results, tell ViewModel to load this cycle's computed results
            androidx.compose.runtime.LaunchedEffect(cycleId) {
                if (cycleId > 0) {
                    wizardViewModel.viewFinalResults(cycleId)
                }
            }

            WizardContainer(
                state = wizardState,
                onStep1Update = { _, _, _, _, _, _ -> },
                onProceedStep1 = {},
                onUpdateReading = { _, _ -> },
                onNextReading = {},
                onPrevReading = {},
                onUndoReading = {},
                onFinishReadings = {},
                onBackToReadings = {},
                onCalculate = {},
                onCloseWizard = {
                    navController.popBackStack()
                },
                currency = currency,
                decimals = decimals
            )
        }

        // Standalone Bill History Screen
        composable("history") {
            HistoryScreen(
                viewModel = historyViewModel,
                onBack = { navController.popBackStack() },
                onResumeWizard = { cycleId ->
                    wizardViewModel.resumeWizard(cycleId)
                    navController.navigate("wizard")
                },
                onViewFinalResults = { cycleId ->
                    navController.navigate("results/$cycleId")
                },
                currency = currency
            )
        }

        // Active Tenant Members List Screen
        composable("members") {
            MembersScreen(
                viewModel = membersViewModel,
                onBack = { navController.popBackStack() }
            )
        }

        // Configuration Settings Screen
        composable("settings") {
            SettingsScreen(
                viewModel = settingsViewModel,
                onBack = { navController.popBackStack() }
            )
        }

        // Audit Logs Screen
        composable("audit") {
            AuditScreen(
                viewModel = auditViewModel,
                onBack = { navController.popBackStack() }
            )
        }

        // About Splash/Specs Screen
        composable("about") {
            AboutScreen(
                onBack = { navController.popBackStack() }
            )
        }
    }
}
