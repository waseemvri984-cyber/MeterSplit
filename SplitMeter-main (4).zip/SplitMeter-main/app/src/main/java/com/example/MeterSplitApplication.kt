package com.example

import android.app.Application
import com.example.data.db.AppDatabase
import com.example.data.repository.MeterSplitRepository

class MeterSplitApplication : Application() {
    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }
    val repository: MeterSplitRepository by lazy { MeterSplitRepository(database) }

    override fun onCreate() {
        super.onCreate()
    }
}
