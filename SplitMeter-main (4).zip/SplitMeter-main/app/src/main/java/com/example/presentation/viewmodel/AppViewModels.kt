package com.example.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.repository.MeterSplitRepository
import com.example.domain.engine.CalculationEngine
import com.example.domain.engine.CalculationException
import com.example.domain.model.AuditLog
import com.example.domain.model.BillingCycle
import com.example.domain.model.Member
import com.example.domain.model.Setting
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

// ==========================================
// 1. MEMBERS VIEWMODEL
// ==========================================
class MembersViewModel(private val repository: MeterSplitRepository) : ViewModel() {

    val members: StateFlow<List<Member>> = repository.allMembers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun saveMember(id: Int, name: String, weeklyHours: Double, displayOrder: Int, isActive: Boolean) {
        viewModelScope.launch {
            val member = Member(id = id, name = name, weeklyHours = weeklyHours, displayOrder = displayOrder, isActive = isActive)
            if (id == 0) {
                repository.insertMember(member)
            } else {
                repository.updateMember(member)
            }
        }
    }

    fun deleteMember(member: Member) {
        viewModelScope.launch {
            repository.deleteMember(member)
        }
    }
}

// ==========================================
// 2. SETTINGS VIEWMODEL
// ==========================================
class SettingsViewModel(private val repository: MeterSplitRepository) : ViewModel() {

    val settings: StateFlow<Map<String, String>> = repository.settingsMap
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    fun saveSetting(key: String, value: String) {
        viewModelScope.launch {
            repository.saveSetting(key, value)
        }
    }
}

// ==========================================
// 3. AUDIT VIEWMODEL
// ==========================================
class AuditViewModel(private val repository: MeterSplitRepository) : ViewModel() {

    val auditLogs: StateFlow<List<AuditLog>> = repository.allAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}

// ==========================================
// 4. HISTORY VIEWMODEL
// ==========================================
class HistoryViewModel(private val repository: MeterSplitRepository) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage = _errorMessage.asStateFlow()

    private val _successMessage = MutableStateFlow<String?>(null)
    val successMessage = _successMessage.asStateFlow()

    val billingCycles: StateFlow<List<BillingCycle>> = combine(
        repository.allBillingCycles,
        _searchQuery
    ) { cycles, query ->
        if (query.isBlank()) {
            cycles
        } else {
            cycles.filter {
                it.month.contains(query, ignoreCase = true) ||
                it.year.toString().contains(query) ||
                it.status.contains(query, ignoreCase = true)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun deleteBillingCycle(id: Int) {
        viewModelScope.launch {
            val cycle = repository.getBillingCycleById(id)
            if (cycle?.status == "Locked") {
                _errorMessage.value = "Cannot delete locked billing cycle!"
                return@launch
            }
            repository.deleteBillingCycle(id)
            _successMessage.value = "Billing cycle deleted successfully!"
        }
    }

    fun toggleLockStatus(id: Int) {
        viewModelScope.launch {
            val cycle = repository.getBillingCycleById(id) ?: return@launch
            val newStatus = if (cycle.status == "Locked") "Unlocked" else "Locked"
            val updated = cycle.copy(status = newStatus)
            repository.updateBillingCycle(updated)
            
            repository.logAction(
                cycle.id,
                "TOGGLE_LOCK",
                "Toggled lock status for ${cycle.month} ${cycle.year} to $newStatus"
            )
            _successMessage.value = "Cycle status changed to $newStatus"
        }
    }

    fun recalculateBilling(id: Int) {
        viewModelScope.launch {
            val cycle = repository.getBillingCycleById(id)
            if (cycle == null) {
                _errorMessage.value = "Billing cycle not found!"
                return@launch
            }
            if (cycle.status == "Locked") {
                _errorMessage.value = "Cannot recalculate a locked billing cycle!"
                return@launch
            }

            try {
                // Fetch the entered readings
                val readings = repository.getReadingsForBillingSync(id)
                // Fetch current members
                val members = repository.allMembers.first()

                // Recalculate
                val newResults = CalculationEngine.calculate(
                    billingCycle = cycle,
                    members = members,
                    readings = readings
                )

                // Save updated results within transaction
                repository.saveWizardState(
                    billingCycle = cycle,
                    readings = readings,
                    results = newResults
                )

                repository.logAction(
                    cycle.id,
                    "RECALCULATE",
                    "Recalculated splits for ${cycle.month} ${cycle.year} with current member configurations"
                )

                _successMessage.value = "Recalculated successfully!"
            } catch (e: CalculationException) {
                _errorMessage.value = "Recalculation error: ${e.message}"
            } catch (e: Exception) {
                _errorMessage.value = "Error: ${e.message}"
            }
        }
    }

    fun clearMessages() {
        _errorMessage.value = null
        _successMessage.value = null
    }
}

// ==========================================
// VIEWMODEL FACTORIES CONTAINER
// ==========================================
class AppViewModelFactory(private val repository: MeterSplitRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(MembersViewModel::class.java) -> MembersViewModel(repository) as T
            modelClass.isAssignableFrom(SettingsViewModel::class.java) -> SettingsViewModel(repository) as T
            modelClass.isAssignableFrom(AuditViewModel::class.java) -> AuditViewModel(repository) as T
            modelClass.isAssignableFrom(HistoryViewModel::class.java) -> HistoryViewModel(repository) as T
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
