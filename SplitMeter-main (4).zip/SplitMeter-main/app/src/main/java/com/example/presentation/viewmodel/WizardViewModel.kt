package com.example.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.repository.MeterSplitRepository
import com.example.domain.engine.CalculationEngine
import com.example.domain.engine.CalculationException
import com.example.domain.model.BillingCycle
import com.example.domain.model.Member
import com.example.domain.model.MemberResult
import com.example.domain.model.Reading
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.Calendar

data class ReadingItemState(
    val sequence: Int,
    val memberId: Int? = null,
    val onReading: Double = 0.0,
    val offReading: Double = 0.0,
    val units: Double = 0.0
)

data class WizardUIState(
    val currentStep: Int = 1, // 1: Input, 2: Reading, 3: Review, 4: Results
    
    // Step 1: Input
    val month: String = "",
    val year: Int = 0,
    val billAmount: Double = 0.0,
    val billUnits: Double = 0.0,
    val firstOn: Double = 0.0,
    val additionalFixedCharge: Double = 1500.0,
    
    // Step 2: Reading Entry
    val readings: List<ReadingItemState> = emptyList(),
    val currentReadingIndex: Int = 0,
    
    // Domain Models & Results
    val members: List<Member> = emptyList(),
    val results: List<MemberResult> = emptyList(),
    
    // Helpers
    val billingCycleId: Int = 0, // 0 means brand new
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null
)

class WizardViewModel(private val repository: MeterSplitRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(WizardUIState())
    val uiState: StateFlow<WizardUIState> = _uiState.asStateFlow()

    init {
        // Load active members and prefill date on init
        resetWizard()
    }

    fun resetWizard() {
        viewModelScope.launch {
            _uiState.value = WizardUIState(isLoading = true)
            val activeMembers = repository.allMembers.first().filter { it.isActive }
            val defaultFixedChargeStr = repository.getSettingValue("default_fixed_charge", "1500.0")
            val defaultFixedCharge = defaultFixedChargeStr.toDoubleOrNull() ?: 1500.0
            
            val calendar = Calendar.getInstance()
            val currentYear = calendar.get(Calendar.YEAR)
            val monthNames = arrayOf(
                "January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
            )
            val currentMonth = monthNames[calendar.get(Calendar.MONTH)]

            _uiState.value = WizardUIState(
                currentStep = 1,
                month = currentMonth,
                year = currentYear,
                additionalFixedCharge = defaultFixedCharge,
                members = activeMembers,
                isLoading = false
            )
        }
    }

    // Step 1: Input Field Updates
    fun updateStep1Fields(
        month: String,
        year: Int,
        billAmount: Double,
        billUnits: Double,
        firstOn: Double,
        additionalFixedCharge: Double
    ) {
        _uiState.value = _uiState.value.copy(
            month = month,
            year = year,
            billAmount = billAmount,
            billUnits = billUnits,
            firstOn = firstOn,
            additionalFixedCharge = additionalFixedCharge,
            errorMessage = null
        )
    }

    // Proceed from Step 1 to Step 2
    fun proceedFromStep1() {
        val state = _uiState.value
        if (state.month.isBlank()) {
            _uiState.value = state.copy(errorMessage = "Month cannot be empty")
            return
        }
        if (state.year <= 0) {
            _uiState.value = state.copy(errorMessage = "Please enter a valid year")
            return
        }
        if (state.billAmount <= 0) {
            _uiState.value = state.copy(errorMessage = "Bill Amount must be greater than zero")
            return
        }
        if (state.billUnits <= 0) {
            _uiState.value = state.copy(errorMessage = "Bill Units must be greater than zero")
            return
        }
        if (state.firstOn < 0) {
            _uiState.value = state.copy(errorMessage = "First ON Reading cannot be negative")
            return
        }

        // Initialize readings. If empty, create the first reading item.
        val existingReadings = state.readings
        val readings = if (existingReadings.isEmpty()) {
            listOf(ReadingItemState(sequence = 1, onReading = state.firstOn))
        } else {
            existingReadings
        }

        _uiState.value = state.copy(
            currentStep = 2,
            readings = readings,
            currentReadingIndex = if (existingReadings.isEmpty()) 0 else state.currentReadingIndex,
            errorMessage = null
        )
    }

    // Step 2: Update current reading inputs
    fun updateCurrentReading(memberId: Int?, offReading: Double) {
        val state = _uiState.value
        val index = state.currentReadingIndex
        if (index < 0 || index >= state.readings.size) return

        val currentItem = state.readings[index]
        val updatedItem = currentItem.copy(
            memberId = memberId,
            offReading = offReading,
            units = (offReading - currentItem.onReading).coerceAtLeast(0.0)
        )

        val updatedList = state.readings.toMutableList().apply {
            set(index, updatedItem)
        }

        _uiState.value = state.copy(readings = updatedList, errorMessage = null)
    }

    // Step 2: Move to NEXT reading
    fun nextReading() {
        val state = _uiState.value
        val index = state.currentReadingIndex
        val currentReading = state.readings.getOrNull(index) ?: return

        // Validate
        if (currentReading.memberId == null) {
            _uiState.value = state.copy(errorMessage = "Please select a member for this reading")
            return
        }
        if (currentReading.offReading < currentReading.onReading) {
            _uiState.value = state.copy(errorMessage = "OFF reading cannot be less than ON reading")
            return
        }

        viewModelScope.launch {
            // Check if there is a next reading in list, if not, create one
            val nextIndex = index + 1
            val updatedReadings = state.readings.toMutableList()
            if (nextIndex >= updatedReadings.size) {
                // Next ON reading auto-fills from current OFF reading
                updatedReadings.add(
                    ReadingItemState(
                        sequence = nextIndex + 1,
                        onReading = currentReading.offReading
                    )
                )
            } else {
                // Update next ON reading to match current OFF reading in case current was updated
                val nextReading = updatedReadings[nextIndex]
                updatedReadings[nextIndex] = nextReading.copy(onReading = currentReading.offReading)
            }

            // Save intermediate progress as an asynchronous database background routine
            saveProgressToDatabase(state.copy(readings = updatedReadings, currentReadingIndex = nextIndex))

            _uiState.value = state.copy(
                readings = updatedReadings,
                currentReadingIndex = nextIndex,
                errorMessage = null
            )
        }
    }

    // Step 2: Go to PREVIOUS reading or step
    fun previousReading() {
        val state = _uiState.value
        val index = state.currentReadingIndex

        if (index == 0) {
            // Go back to step 1
            _uiState.value = state.copy(currentStep = 1, errorMessage = null)
        } else {
            _uiState.value = state.copy(
                currentReadingIndex = index - 1,
                errorMessage = null
            )
        }
    }

    // Step 2: Undo the last entered reading (removes the last reading and moves index back)
    fun undoLastReading() {
        val state = _uiState.value
        if (state.readings.size <= 1) {
            _uiState.value = state.copy(errorMessage = "Cannot undo. Only one reading exists.")
            return
        }

        val updatedReadings = state.readings.toMutableList()
        val indexToUndo = state.currentReadingIndex

        if (indexToUndo > 0) {
            // Remove the newest or current if we are at the end
            updatedReadings.removeAt(indexToUndo)
            val newIndex = indexToUndo - 1
            _uiState.value = state.copy(
                readings = updatedReadings,
                currentReadingIndex = newIndex,
                errorMessage = "Undid last reading sequence ${indexToUndo + 1}"
            )
        } else {
            // We are at index 0 but there are more items? Clean up future items
            _uiState.value = state.copy(
                readings = listOf(state.readings[0]),
                currentReadingIndex = 0,
                errorMessage = "Reset readings to start"
            )
        }
    }

    // Step 2: Proceed to Step 3 (Review Screen)
    fun finishReadings() {
        val state = _uiState.value
        val index = state.currentReadingIndex
        val currentReading = state.readings.getOrNull(index) ?: return

        // Validate current reading before finishing
        if (currentReading.memberId == null) {
            _uiState.value = state.copy(errorMessage = "Please select a member for this reading")
            return
        }
        if (currentReading.offReading < currentReading.onReading) {
            _uiState.value = state.copy(errorMessage = "OFF reading cannot be less than ON reading")
            return
        }

        _uiState.value = state.copy(
            currentStep = 3,
            errorMessage = null
        )
    }

    // Step 3: Go back to Step 2
    fun backToReadings() {
        _uiState.value = _uiState.value.copy(
            currentStep = 2,
            errorMessage = null
        )
    }

    // Step 3: Run calculation engine and save draft
    fun calculateAndShowResults() {
        viewModelScope.launch {
            val state = _uiState.value
            _uiState.value = state.copy(isLoading = true, errorMessage = null)

            try {
                // Map UI states to DB entities
                val billingCycle = BillingCycle(
                    id = state.billingCycleId,
                    month = state.month,
                    year = state.year,
                    billAmount = state.billAmount,
                    additionalFixedCharge = state.additionalFixedCharge,
                    billUnits = state.billUnits,
                    firstOn = state.firstOn,
                    status = "Draft" // Init as draft
                )

                val domainReadings = state.readings.map {
                    Reading(
                        billingId = state.billingCycleId,
                        sequence = it.sequence,
                        memberId = it.memberId ?: throw CalculationException("Reading sequence ${it.sequence} is missing a member"),
                        onReading = it.onReading,
                        offReading = it.offReading,
                        units = it.units
                    )
                }

                // Execute deterministic pure calculation engine
                val calculatedResults = CalculationEngine.calculate(
                    billingCycle = billingCycle,
                    members = state.members,
                    readings = domainReadings
                )

                // Save fully in database within transaction
                repository.saveWizardState(
                    billingCycle = billingCycle,
                    readings = domainReadings,
                    results = calculatedResults
                )

                // If saved successfully, retrieve updated ID if it was 0
                val savedCycles = repository.allBillingCycles.first()
                val finalCycleId = if (state.billingCycleId == 0) {
                    savedCycles.firstOrNull()?.id ?: 0
                } else {
                    state.billingCycleId
                }

                repository.logAction(
                    finalCycleId,
                    "CALCULATE_METER_SPLIT",
                    "Calculated and finalized splits for ${state.month} ${state.year}. Payable Grand Total: ${state.billAmount + state.additionalFixedCharge}"
                )

                _uiState.value = state.copy(
                    billingCycleId = finalCycleId,
                    results = calculatedResults,
                    currentStep = 4,
                    isLoading = false,
                    successMessage = "Billing calculation completed successfully!"
                )

            } catch (e: CalculationException) {
                _uiState.value = state.copy(
                    isLoading = false,
                    errorMessage = e.message ?: "Calculation failed. Check readings."
                )
            } catch (e: Exception) {
                _uiState.value = state.copy(
                    isLoading = false,
                    errorMessage = "An error occurred: ${e.message}"
                )
            }
        }
    }

    // Resume Wizard from history or draft
    fun resumeWizard(cycleId: Int) {
        viewModelScope.launch {
            _uiState.value = WizardUIState(isLoading = true)
            val cycle = repository.getBillingCycleById(cycleId)
            if (cycle == null) {
                _uiState.value = WizardUIState(errorMessage = "Billing cycle $cycleId not found")
                return@launch
            }

            // Check if locked
            if (cycle.status == "Locked") {
                _uiState.value = WizardUIState(errorMessage = "Cannot edit. Billing cycle is locked.")
                return@launch
            }

            val activeMembers = repository.allMembers.first()
            val readings = repository.getReadingsForBillingSync(cycleId).map {
                ReadingItemState(
                    sequence = it.sequence,
                    memberId = it.memberId,
                    onReading = it.onReading,
                    offReading = it.offReading,
                    units = it.units
                )
            }

            val results = repository.getResultsForBillingSync(cycleId)

            _uiState.value = WizardUIState(
                currentStep = if (results.isNotEmpty()) 4 else 2,
                month = cycle.month,
                year = cycle.year,
                billAmount = cycle.billAmount,
                billUnits = cycle.billUnits,
                firstOn = cycle.firstOn,
                additionalFixedCharge = cycle.additionalFixedCharge,
                readings = readings.ifEmpty { listOf(ReadingItemState(sequence = 1, onReading = cycle.firstOn)) },
                currentReadingIndex = if (readings.isNotEmpty()) readings.size - 1 else 0,
                members = activeMembers,
                results = results,
                billingCycleId = cycleId,
                isLoading = false
            )
        }
    }

    // Standalone results view (for finalized cycles)
    fun viewFinalResults(cycleId: Int) {
        viewModelScope.launch {
            _uiState.value = WizardUIState(isLoading = true)
            val cycle = repository.getBillingCycleById(cycleId)
            if (cycle == null) {
                _uiState.value = WizardUIState(errorMessage = "Billing cycle not found")
                return@launch
            }

            val members = repository.allMembers.first()
            val readings = repository.getReadingsForBillingSync(cycleId).map {
                ReadingItemState(
                    sequence = it.sequence,
                    memberId = it.memberId,
                    onReading = it.onReading,
                    offReading = it.offReading,
                    units = it.units
                )
            }
            val results = repository.getResultsForBillingSync(cycleId)

            _uiState.value = WizardUIState(
                currentStep = 4,
                month = cycle.month,
                year = cycle.year,
                billAmount = cycle.billAmount,
                billUnits = cycle.billUnits,
                firstOn = cycle.firstOn,
                additionalFixedCharge = cycle.additionalFixedCharge,
                readings = readings,
                members = members,
                results = results,
                billingCycleId = cycleId,
                isLoading = false
            )
        }
    }

    // Asynchronous database background auto-save routine
    private suspend fun saveProgressToDatabase(currentState: WizardUIState) {
        try {
            val billingCycle = BillingCycle(
                id = currentState.billingCycleId,
                month = currentState.month,
                year = currentState.year,
                billAmount = currentState.billAmount,
                additionalFixedCharge = currentState.additionalFixedCharge,
                billUnits = currentState.billUnits,
                firstOn = currentState.firstOn,
                status = "Draft"
            )

            val domainReadings = currentState.readings.filter { it.memberId != null }.map {
                Reading(
                    billingId = currentState.billingCycleId,
                    sequence = it.sequence,
                    memberId = it.memberId!!,
                    onReading = it.onReading,
                    offReading = it.offReading,
                    units = it.units
                )
            }

            repository.saveWizardState(
                billingCycle = billingCycle,
                readings = domainReadings
            )

            // Update billingCycleId if it was newly created
            if (currentState.billingCycleId == 0) {
                val lastCycle = repository.allBillingCycles.first().firstOrNull()
                if (lastCycle != null) {
                    _uiState.value = _uiState.value.copy(billingCycleId = lastCycle.id)
                }
            }
        } catch (e: Exception) {
            // Silently fail or log to standard streams for background tasks, avoid crashing UI
            e.printStackTrace()
        }
    }
}

class WizardViewModelFactory(private val repository: MeterSplitRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(WizardViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return WizardViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
