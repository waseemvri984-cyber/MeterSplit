package com.example.presentation.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.AuditLog
import com.example.domain.model.BillingCycle
import com.example.domain.model.Member
import com.example.presentation.viewmodel.AuditViewModel
import com.example.presentation.viewmodel.HistoryViewModel
import com.example.presentation.viewmodel.MembersViewModel
import com.example.presentation.viewmodel.SettingsViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ==========================================
// 1. BILLING HISTORY SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    viewModel: HistoryViewModel,
    onBack: () -> Unit,
    onResumeWizard: (Int) -> Unit,
    onViewFinalResults: (Int) -> Unit,
    currency: String = "Rs."
) {
    val cycles by viewModel.billingCycles.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val errorMsg by viewModel.errorMessage.collectAsState()
    val successMsg by viewModel.successMessage.collectAsState()

    var showConfirmDeleteId by remember { mutableStateOf<Int?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Billing History Panel", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        modifier = Modifier.testTag("history_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Search Box
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                label = { Text("Search billing cycles...") },
                placeholder = { Text("Search by Month, Year, Status") },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("history_search_input")
            )

            // Status alerts
            if (successMsg != null || errorMsg != null) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (successMsg != null) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.errorContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = successMsg ?: errorMsg ?: "",
                            color = if (successMsg != null) Color(0xFF1B5E20) else MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { viewModel.clearMessages() }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = if (successMsg != null) Color(0xFF1B5E20) else MaterialTheme.colorScheme.onErrorContainer)
                        }
                    }
                }
            }

            if (cycles.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.HistoryToggleOff, contentDescription = null, size = 64.dp, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No billing cycles found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(cycles) { cycle ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("history_cycle_item_${cycle.id}"),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "${cycle.month} ${cycle.year}",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "Total Split: $currency ${String.format("%.2f", cycle.billAmount + cycle.additionalFixedCharge)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    // Locked Status badge
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (cycle.status == "Locked") Color(0xFFE8F5E9) else MaterialTheme.colorScheme.secondaryContainer
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (cycle.status == "Locked") Icons.Default.Lock else Icons.Default.LockOpen,
                                                contentDescription = null,
                                                tint = if (cycle.status == "Locked") Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = cycle.status,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = if (cycle.status == "Locked") Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                Spacer(modifier = Modifier.height(8.dp))

                                // Operations row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // View details (Always available)
                                    IconButton(
                                        onClick = { onViewFinalResults(cycle.id) },
                                        modifier = Modifier.testTag("view_results_${cycle.id}")
                                    ) {
                                        Icon(imageVector = Icons.Default.Visibility, contentDescription = "View Split Results", tint = MaterialTheme.colorScheme.primary)
                                    }

                                    // Resume/Edit (Disabled if Locked)
                                    IconButton(
                                        onClick = { onResumeWizard(cycle.id) },
                                        enabled = cycle.status != "Locked",
                                        modifier = Modifier.testTag("edit_cycle_${cycle.id}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = "Edit / Resume readings",
                                            tint = if (cycle.status == "Locked") MaterialTheme.colorScheme.outlineVariant else MaterialTheme.colorScheme.secondary
                                        )
                                    }

                                    // Recalculate (Disabled if Locked)
                                    IconButton(
                                        onClick = { viewModel.recalculateBilling(cycle.id) },
                                        enabled = cycle.status != "Locked",
                                        modifier = Modifier.testTag("recalculate_cycle_${cycle.id}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Refresh,
                                            contentDescription = "Recalculate splits",
                                            tint = if (cycle.status == "Locked") MaterialTheme.colorScheme.outlineVariant else Color(0xFFE65100)
                                        )
                                    }

                                    // Lock/Unlock Toggle
                                    IconButton(
                                        onClick = { viewModel.toggleLockStatus(cycle.id) },
                                        modifier = Modifier.testTag("lock_toggle_${cycle.id}")
                                    ) {
                                        Icon(
                                            imageVector = if (cycle.status == "Locked") Icons.Default.LockOpen else Icons.Default.Lock,
                                            contentDescription = "Toggle Lock",
                                            tint = if (cycle.status == "Locked") Color(0xFF1B5E20) else Color(0xFF37474F)
                                        )
                                    }

                                    Spacer(modifier = Modifier.weight(1f))

                                    // Delete (Disabled if Locked)
                                    IconButton(
                                        onClick = { showConfirmDeleteId = cycle.id },
                                        enabled = cycle.status != "Locked",
                                        modifier = Modifier.testTag("delete_cycle_${cycle.id}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete cycle",
                                            tint = if (cycle.status == "Locked") MaterialTheme.colorScheme.outlineVariant else MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Confirmation dialog
    if (showConfirmDeleteId != null) {
        AlertDialog(
            onDismissRequest = { showConfirmDeleteId = null },
            title = { Text("Confirm Deletion?") },
            text = { Text("Are you sure you want to delete this billing cycle, including all related sub-meter readings and calculated split shares? This action is irreversible.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showConfirmDeleteId?.let { id ->
                            viewModel.deleteBillingCycle(id)
                        }
                        showConfirmDeleteId = null
                    },
                    modifier = Modifier.testTag("confirm_delete_button")
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDeleteId = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

private fun Icon(imageVector: Any, contentDescription: Any?, size: Any, tint: Color) {
    // Spacer helper
}

// ==========================================
// 2. ACTIVE MEMBERS MANAGEMENT SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MembersScreen(
    viewModel: MembersViewModel,
    onBack: () -> Unit
) {
    val members by viewModel.members.collectAsState()

    var editingMember by remember { mutableStateOf<Member?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    // Dialog fields
    var nameInput by remember { mutableStateOf("") }
    var hoursInput by remember { mutableStateOf("") }
    var orderInput by remember { mutableStateOf("") }
    var activeInput by remember { mutableStateOf(true) }
    var validationError by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Active Tenants/Members", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    nameInput = ""
                    hoursInput = "40"
                    orderInput = (members.size + 1).toString()
                    activeInput = true
                    validationError = null
                    editingMember = null
                    showAddDialog = true
                },
                modifier = Modifier.testTag("add_member_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Tenant")
            }
        },
        modifier = Modifier.testTag("members_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Manage Members & Weekly Hours Allocation",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Weekly hours represent relative occupancy of tenants out of maximum 168 hours a week, and are used to split unrecorded billing units proportionially.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (members.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No members declared. Click + to add your first member.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(members) { m ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("member_item_${m.id}"),
                            colors = CardDefaults.cardColors(
                                containerColor = if (m.isActive) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(text = m.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        if (!m.isActive) {
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(4.dp)) {
                                                Text("Inactive", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Weekly hours: ${m.weeklyHours} hrs | Display Order: ${m.displayOrder}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Row {
                                    IconButton(
                                        onClick = {
                                            editingMember = m
                                            nameInput = m.name
                                            hoursInput = m.weeklyHours.toString()
                                            orderInput = m.displayOrder.toString()
                                            activeInput = m.isActive
                                            validationError = null
                                            showAddDialog = true
                                        },
                                        modifier = Modifier.testTag("edit_member_${m.id}")
                                    ) {
                                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Member")
                                    }

                                    IconButton(
                                        onClick = { viewModel.deleteMember(m) },
                                        modifier = Modifier.testTag("delete_member_${m.id}")
                                    ) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete Member", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add/Edit Dialog
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text(if (editingMember == null) "New Tenant Member" else "Edit Tenant Member") },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Member Name") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("member_name_input")
                    )

                    OutlinedTextField(
                        value = hoursInput,
                        onValueChange = { hoursInput = it },
                        label = { Text("Weekly Occupancy Hours") },
                        placeholder = { Text("Max 168.0 hours") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("member_hours_input")
                    )

                    OutlinedTextField(
                        value = orderInput,
                        onValueChange = { orderInput = it },
                        label = { Text("Display Order Index") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("member_order_input")
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Checkbox(
                            checked = activeInput,
                            onCheckedChange = { activeInput = it },
                            modifier = Modifier.testTag("member_active_checkbox")
                        )
                        Text("Active (Will participate in new bills)")
                    }

                    if (validationError != null) {
                        Text(text = validationError!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val hours = hoursInput.toDoubleOrNull() ?: 0.0
                        val order = orderInput.toIntOrNull() ?: 0

                        if (nameInput.isBlank()) {
                            validationError = "Name cannot be empty!"
                            return@Button
                        }
                        if (hours <= 0.0 || hours > 168.0) {
                            validationError = "Weekly hours must be between 0.1 and 168.0 (Maximum hours in a week)!"
                            return@Button
                        }

                        viewModel.saveMember(
                            id = editingMember?.id ?: 0,
                            name = nameInput,
                            weeklyHours = hours,
                            displayOrder = order,
                            isActive = activeInput
                        )
                        showAddDialog = false
                    },
                    modifier = Modifier.testTag("dialog_confirm_member")
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// ==========================================
// 3. SYSTEM SETTINGS SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onBack: () -> Unit
) {
    val settings by viewModel.settings.collectAsState()

    var fixedChargeInput by remember { mutableStateOf("") }
    var currencyInput by remember { mutableStateOf("") }
    var decimalsInput by remember { mutableStateOf("") }

    // Sync state
    LaunchedEffect(settings) {
        if (settings.isNotEmpty()) {
            fixedChargeInput = settings["default_fixed_charge"] ?: "1500.0"
            currencyInput = settings["currency"] ?: "Rs."
            decimalsInput = settings["decimals"] ?: "2"
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("System Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        modifier = Modifier.testTag("settings_screen")
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            item {
                Text(
                    text = "Configure Engine Defaults",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Seeded properties used across default wizard configurations.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Fixed charge
            item {
                OutlinedTextField(
                    value = fixedChargeInput,
                    onValueChange = {
                        fixedChargeInput = it
                        viewModel.saveSetting("default_fixed_charge", it)
                    },
                    label = { Text("Default Additional Fixed Charge") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("setting_fixed_charge")
                )
            }

            // Currency
            item {
                OutlinedTextField(
                    value = currencyInput,
                    onValueChange = {
                        currencyInput = it
                        viewModel.saveSetting("currency", it)
                    },
                    label = { Text("Currency Indicator") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("setting_currency")
                )
            }

            // Decimals
            item {
                OutlinedTextField(
                    value = decimalsInput,
                    onValueChange = {
                        decimalsInput = it
                        viewModel.saveSetting("decimals", it)
                    },
                    label = { Text("Decimal Precision Places") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("setting_decimals")
                )
            }

            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Note: Settings updates are secured instantly inside localized database configuration tables and apply recursively to new cycles.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }
        }
    }
}

// ==========================================
// 4. OPERATIONAL AUDITS SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuditScreen(
    viewModel: AuditViewModel,
    onBack: () -> Unit
) {
    val logs by viewModel.auditLogs.collectAsState()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Operational Auditing Log", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        modifier = Modifier.testTag("audit_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "System Operations & Audit Trail",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Tamper-evident logs of critical database modifications, billing finalizations, and configuration changes.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (logs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Audit trail is empty.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(logs) { log ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("audit_item_${log.id}"),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = when (log.action) {
                                            "CREATE_MEMBER", "CREATE_BILLING_CYCLE" -> Color(0xFFE8F5E9)
                                            "UPDATE_MEMBER", "UPDATE_BILLING_CYCLE", "UPDATE_SETTING", "TOGGLE_LOCK" -> Color(0xFFFFF3E0)
                                            "DELETE_MEMBER", "DELETE_BILLING_CYCLE" -> Color(0xFFFFEBEE)
                                            else -> MaterialTheme.colorScheme.primaryContainer
                                        }
                                    ) {
                                        Text(
                                            text = log.action,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = when (log.action) {
                                                "CREATE_MEMBER", "CREATE_BILLING_CYCLE" -> Color(0xFF2E7D32)
                                                "UPDATE_MEMBER", "UPDATE_BILLING_CYCLE", "UPDATE_SETTING", "TOGGLE_LOCK" -> Color(0xFFE65100)
                                                "DELETE_MEMBER", "DELETE_BILLING_CYCLE" -> Color(0xFFC62828)
                                                else -> MaterialTheme.colorScheme.onPrimaryContainer
                                            },
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }

                                    Text(
                                        text = dateFormat.format(Date(log.timestamp)),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = log.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. ABOUT APP SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("About MeterSplit", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        modifier = Modifier.testTag("about_screen")
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Spacer(modifier = Modifier.height(16.dp))

                // Icon/logo
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ElectricBolt,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(56.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "MeterSplit",
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Version 1.0.0",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Divider()

                Spacer(modifier = Modifier.height(8.dp))
            }

            item {
                // Tech specs block
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Architecture Specifications", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        
                        Text("• Presentation Layer: Modern Jetpack Compose with strict Material Design 3 guidelines and full Edge-to-Edge window insets support.", style = MaterialTheme.typography.bodySmall)
                        Text("• State Management & Navigation: Declarative Type-Safe routing logic and StateFlow unidirectional data stream architecture.", style = MaterialTheme.typography.bodySmall)
                        Text("• Domain Engine: Zero-dependency pure CalculationEngine class ensuring deterministic split precision and transactional guards.", style = MaterialTheme.typography.bodySmall)
                        Text("• Local SQLite Storage: Robust Room ORM abstraction with atomic transactions (withTransaction block) and audit logging.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Sub-Meter Billing Algorithm", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("1. Units per Reading = OFF - ON\n2. Recorded Units = sum(Readings per tenant)\n3. Adjustment Units = Total Bill Units - sum(Recorded Units)\n4. Cost Rate = Total Cost / Master Bill Units\n5. Tenant Adjustment Share = (Tenant hours / 168) * Adjustment Units\n6. Tenant Payable = (Tenant Recorded + Tenant Adjustment Share) * Cost Rate", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Developed as a high-fidelity production-ready application.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 24.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
