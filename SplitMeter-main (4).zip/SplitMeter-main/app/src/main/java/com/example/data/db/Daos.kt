package com.example.data.db

import androidx.room.*
import com.example.domain.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MemberDao {
    @Query("SELECT * FROM members ORDER BY displayOrder ASC")
    fun getAllMembers(): Flow<List<Member>>

    @Query("SELECT * FROM members WHERE id = :id")
    suspend fun getMemberById(id: Int): Member?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMember(member: Member): Long

    @Update
    suspend fun updateMember(member: Member)

    @Delete
    suspend fun deleteMember(member: Member)
}

@Dao
interface BillingCycleDao {
    @Query("SELECT * FROM billing_cycles ORDER BY year DESC, month DESC, createdAt DESC")
    fun getAllBillingCycles(): Flow<List<BillingCycle>>

    @Query("SELECT * FROM billing_cycles WHERE id = :id")
    suspend fun getBillingCycleById(id: Int): BillingCycle?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBillingCycle(billingCycle: BillingCycle): Long

    @Update
    suspend fun updateBillingCycle(billingCycle: BillingCycle)

    @Delete
    suspend fun deleteBillingCycle(billingCycle: BillingCycle)
}

@Dao
interface ReadingDao {
    @Query("SELECT * FROM readings WHERE billingId = :billingId ORDER BY sequence ASC")
    fun getReadingsForBilling(billingId: Int): Flow<List<Reading>>

    @Query("SELECT * FROM readings WHERE billingId = :billingId ORDER BY sequence ASC")
    suspend fun getReadingsForBillingSync(billingId: Int): List<Reading>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReading(reading: Reading): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReadings(readings: List<Reading>)

    @Query("DELETE FROM readings WHERE billingId = :billingId")
    suspend fun deleteReadingsForBilling(billingId: Int)
}

@Dao
interface MemberResultDao {
    @Query("SELECT * FROM member_results WHERE billingId = :billingId")
    fun getResultsForBilling(billingId: Int): Flow<List<MemberResult>>

    @Query("SELECT * FROM member_results WHERE billingId = :billingId")
    suspend fun getResultsForBillingSync(billingId: Int): List<MemberResult>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemberResults(results: List<MemberResult>)

    @Query("DELETE FROM member_results WHERE billingId = :billingId")
    suspend fun deleteResultsForBilling(billingId: Int)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_log ORDER BY timestamp DESC")
    fun getAllAuditLogs(): Flow<List<AuditLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLog): Long
}

@Dao
interface SettingDao {
    @Query("SELECT * FROM settings")
    fun getAllSettings(): Flow<List<Setting>>

    @Query("SELECT * FROM settings WHERE `key` = :key LIMIT 1")
    suspend fun getSettingByKey(key: String): Setting?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSetting(setting: Setting)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSettings(settings: List<Setting>)
}
