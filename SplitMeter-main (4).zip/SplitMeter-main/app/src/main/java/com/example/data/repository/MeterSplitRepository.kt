package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.db.AppDatabase
import com.example.domain.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class MeterSplitRepository(private val db: AppDatabase) {

    private val memberDao = db.memberDao()
    private val billingCycleDao = db.billingCycleDao()
    private val readingDao = db.readingDao()
    private val memberResultDao = db.memberResultDao()
    private val auditLogDao = db.auditLogDao()
    private val settingDao = db.settingDao()

    // Members
    val allMembers: Flow<List<Member>> = memberDao.getAllMembers()
    suspend fun getMemberById(id: Int): Member? = memberDao.getMemberById(id)

    suspend fun insertMember(member: Member): Long {
        val id = memberDao.insertMember(member)
        logAction(null, "CREATE_MEMBER", "Created member '${member.name}' (ID $id) with weekly hours ${member.weeklyHours}")
        return id
    }

    suspend fun updateMember(member: Member) {
        memberDao.updateMember(member)
        logAction(null, "UPDATE_MEMBER", "Updated member '${member.name}' (ID ${member.id}) with weekly hours ${member.weeklyHours}")
    }

    suspend fun deleteMember(member: Member) {
        memberDao.deleteMember(member)
        logAction(null, "DELETE_MEMBER", "Deleted member '${member.name}' (ID ${member.id})")
    }

    // Billing Cycles
    val allBillingCycles: Flow<List<BillingCycle>> = billingCycleDao.getAllBillingCycles()
    suspend fun getBillingCycleById(id: Int): BillingCycle? = billingCycleDao.getBillingCycleById(id)

    suspend fun insertBillingCycle(billingCycle: BillingCycle): Long {
        val id = billingCycleDao.insertBillingCycle(billingCycle)
        logAction(id.toInt(), "CREATE_BILLING_CYCLE", "Created billing cycle for ${billingCycle.month} ${billingCycle.year} (Amount: ${billingCycle.billAmount}, Units: ${billingCycle.billUnits})")
        return id
    }

    suspend fun updateBillingCycle(billingCycle: BillingCycle) {
        billingCycleDao.updateBillingCycle(billingCycle)
        logAction(billingCycle.id, "UPDATE_BILLING_CYCLE", "Updated billing cycle state/info. Status: ${billingCycle.status}")
    }

    suspend fun deleteBillingCycle(billingId: Int) {
        val cycle = billingCycleDao.getBillingCycleById(billingId) ?: return
        db.withTransaction {
            readingDao.deleteReadingsForBilling(billingId)
            memberResultDao.deleteResultsForBilling(billingId)
            billingCycleDao.deleteBillingCycle(cycle)
        }
        logAction(null, "DELETE_BILLING_CYCLE", "Deleted billing cycle for ${cycle.month} ${cycle.year} and all related readings and results")
    }

    // Readings
    fun getReadingsForBilling(billingId: Int): Flow<List<Reading>> = readingDao.getReadingsForBilling(billingId)
    suspend fun getReadingsForBillingSync(billingId: Int): List<Reading> = readingDao.getReadingsForBillingSync(billingId)

    // Member Results
    fun getResultsForBilling(billingId: Int): Flow<List<MemberResult>> = memberResultDao.getResultsForBilling(billingId)
    suspend fun getResultsForBillingSync(billingId: Int): List<MemberResult> = memberResultDao.getResultsForBillingSync(billingId)

    // Audit Logs
    val allAuditLogs: Flow<List<AuditLog>> = auditLogDao.getAllAuditLogs()
    suspend fun logAction(billingId: Int?, action: String, description: String) {
        val log = AuditLog(
            billingId = billingId,
            action = action,
            description = description
        )
        auditLogDao.insertAuditLog(log)
    }

    // Settings
    val allSettings: Flow<List<Setting>> = settingDao.getAllSettings()
    val settingsMap: Flow<Map<String, String>> = settingDao.getAllSettings().map { list ->
        list.associate { it.key to it.value }
    }

    suspend fun getSettingValue(key: String, defaultValue: String): String {
        return settingDao.getSettingByKey(key)?.value ?: defaultValue
    }

    suspend fun saveSetting(key: String, value: String) {
        val existing = settingDao.getSettingByKey(key)
        if (existing != null) {
            settingDao.insertSetting(existing.copy(value = value))
        } else {
            settingDao.insertSetting(Setting(key = key, value = value))
        }
        logAction(null, "UPDATE_SETTING", "Updated setting '$key' to '$value'")
    }

    // Transactional save for reading entry wizard data
    suspend fun saveWizardState(
        billingCycle: BillingCycle,
        readings: List<Reading>,
        results: List<MemberResult>? = null
    ) {
        db.withTransaction {
            // 1. Update/Save Billing Cycle
            val bId = if (billingCycle.id == 0) {
                billingCycleDao.insertBillingCycle(billingCycle).toInt()
            } else {
                billingCycleDao.updateBillingCycle(billingCycle)
                billingCycle.id
            }

            // 2. Overwrite readings for this cycle
            readingDao.deleteReadingsForBilling(bId)
            val readingsWithId = readings.map { it.copy(billingId = bId) }
            readingDao.insertReadings(readingsWithId)

            // 3. Overwrite results if available
            memberResultDao.deleteResultsForBilling(bId)
            if (results != null) {
                val resultsWithId = results.map { it.copy(billingId = bId) }
                memberResultDao.insertMemberResults(resultsWithId)
            }
        }
        logAction(billingCycle.id, "SAVE_WIZARD_PROGRESS", "Saved wizard progress for ${billingCycle.month} ${billingCycle.year} (${readings.size} readings stored)")
    }
}
